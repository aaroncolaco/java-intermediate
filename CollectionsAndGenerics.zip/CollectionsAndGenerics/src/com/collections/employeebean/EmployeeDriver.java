package com.collections.employeebean;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class EmployeeDriver {

	Set<EmployeeBean> employeeSet = new TreeSet<>();

	public static void main(String[] args) throws ParseException {
		EmployeeDriver employeeDriver = new EmployeeDriver();
		List<EmployeeBean> employeeList = new ArrayList<>();
		
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MMM-yyy");
		
		// done
		employeeDriver.populateList();
		
		// done
		employeeList = employeeDriver.joinedBefore(simpleDateFormat.parse("23-OCT-2016"));
		System.out.println("Before a date: " + employeeList);
		
		employeeList = employeeDriver.joinedSixMonthsBefore();
		
	}

	public void populateList() {
		EmployeeBean employee;

		employee = new EmployeeBean(3, "John", "07-JUN-2013");
		employeeSet.add(employee);

		employee = new EmployeeBean(4, "Aaron", "23-NOV-2016");
		employeeSet.add(employee);

		employee = new EmployeeBean(9, "Jane", "23-MAY-2016");
		employeeSet.add(employee);

		System.out.println("After populating: " + employeeSet);
	}
	
	public List<EmployeeBean> joinedBefore(Date date) {
		List<EmployeeBean> employeeList = new ArrayList<>();
		
		for (EmployeeBean employee : employeeSet) {
			if (employee.getDateOfJoining().before(date)) {
				employeeList.add(employee);
			}
		}
		return employeeList;
	}
	
	public List<EmployeeBean> joinedSixMonthsBefore() {
		List<EmployeeBean> employeeList = new ArrayList<>();
		
//		Calendar now, join;
//		now = join = Calendar.getInstance();
		
		
		for (EmployeeBean employee : employeeSet) {
//			join.setTime(employee.getDateOfJoining());
			
			long diffInMillis = (new Date().getTime()) - employee.getDateOfJoining().getTime();
			Calendar c = Calendar.getInstance();
			c.setTimeInMillis(diffInMillis);
			int mMonth = c.get(Calendar.MONTH);
			System.out.println(mMonth);
			System.out.println(c.get(Calendar.DAY_OF_MONTH) + " - " + c.get(Calendar.MONTH) + " - " + c.get(Calendar.YEAR));
			
			if (mMonth >= 6) {
				employeeList.add(arg0)
			}
		}
		
		

		
		
		
		return employeeList;
	}
}
