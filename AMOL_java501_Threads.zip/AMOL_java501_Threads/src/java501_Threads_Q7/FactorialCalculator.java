package java501_Threads_Q7;

public class FactorialCalculator {
	private int n;
	private boolean available=false;
	private boolean check=false;
	
	public boolean isCheck() {
		return check;
	}

	public void setCheck(boolean check) {
		this.check = check;
	}

	public synchronized void findFact() {
		 while (available == false) {
	         try {
	            wait();
	         }
	         catch (InterruptedException e) {
	         }
	      }
		 
	      available = false;
	      int fact=1;
	      for (int c = 1 ; c <= n ; c++ )
	            fact = fact*c;
	      System.out.println("Factorial of "+n+" is "+fact);
	      notifyAll();
	}

	public synchronized void read(int x) {
		while (available == true) {
	         try {
	            wait();
	         }
	         catch (InterruptedException e) { 
	         } 
	      }
		  System.out.println("Number read from file:"+x);
	      this.n = x;
	      available = true;
	      notifyAll();
	}

	public int fact(int i){
		int result=1;
		while(i>0){
			result*=i;
			i--;
		}
		return result;
	}
	
	
	public static void main(String[] args) {
		FactorialCalculator factorialCalculator = new FactorialCalculator();
		new FileRead(factorialCalculator,"Numbers.txt");
		new ComputeFact(factorialCalculator);
	}
}
