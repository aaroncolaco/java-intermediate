package java501_Threads_Q7;

public class ComputeFact extends Thread{
	FactorialCalculator f;
	int number;
	public ComputeFact(FactorialCalculator r) {
	      this.f = r;
	      this.number = 0;
	      start();
	   }
	   public void run() {
	         while(!f.isCheck()){
	        	 f.findFact();
	        	 number++;
	         }
	   }

}

