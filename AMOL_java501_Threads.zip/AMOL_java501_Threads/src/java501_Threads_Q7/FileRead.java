package java501_Threads_Q7;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class FileRead extends Thread{
	 private FactorialCalculator r;
	 private String files;
	   public FileRead(FactorialCalculator c ,String b) {
	      this.r = c;
	      this.files = b;
	      start();
	   }
	   
	   public void run() {
		   File file=new File(files);
			Scanner scanner;
			try {
				scanner = new Scanner(file);
				 	do{
					   final String lineFromFile = scanner.nextLine();
					   r.read(Integer.parseInt(lineFromFile));
					}while (scanner.hasNextLine());
				r.setCheck(true);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	  }

}


	
