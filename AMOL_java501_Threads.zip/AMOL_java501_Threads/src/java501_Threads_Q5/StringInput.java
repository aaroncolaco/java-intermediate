package java501_Threads_Q5;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StringInput {
	public static void main(String[] args) {
		List<String> list = new ArrayList<String>();
		for(int i=0;i<4;i++){
			Scanner sc = new Scanner(System.in);
			list.add(sc.nextLine());
		}
		ReadFile r1 = new ReadFile(list.get(0));
		ReadFile r2 = new ReadFile(list.get(1));
		ReadFile r3 = new ReadFile(list.get(2));
		ReadFile r4 = new ReadFile(list.get(3));
	}
}
