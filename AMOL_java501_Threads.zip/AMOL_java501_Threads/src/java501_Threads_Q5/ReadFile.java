package java501_Threads_Q5;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ReadFile extends Thread{
	
	String str;
	public ReadFile(String str) {
		// TODO Auto-generated constructor stub
		this.str=str;
		start();
	}
	
	@Override
	public synchronized void run() {
		// TODO Auto-generated method stub
		super.run();
		System.out.println("IN RUn");
		String temp;
		
		try {
			BufferedReader br = new BufferedReader(new FileReader("file.txt"));
			while((temp=br.readLine())!=null){
				System.out.println(temp + " : " + str);
				if(temp.contains(str))
					System.out.println("String " + str + " file");
			}
			br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
