package java501_Threads_Q1_2;

public class ThreadPrioritySleep extends Thread{
	public ThreadPrioritySleep(String name) {
		// TODO Auto-generated constructor stub
		setName(name);
	}
	
	public void run() {
		// TODO Auto-generated method stub
		super.run();
		for (int i = 0; i < 5; i++) {
			System.out.println(getName() + "Instance " + i);
			try {
				if(getPriority() == Thread.MAX_PRIORITY)
					sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public static void main(String[] args) {
		ThreadPrioritySleep t1 = new ThreadPrioritySleep("T1");
		ThreadPrioritySleep t2 = new ThreadPrioritySleep("T2");
		
		t1.setPriority(MIN_PRIORITY);
		t2.setPriority(MAX_PRIORITY);
		
		t1.start();
		t2.start();
	}
}
