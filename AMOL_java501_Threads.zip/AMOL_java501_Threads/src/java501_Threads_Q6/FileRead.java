package java501_Threads_Q6;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class FileRead {
	public static void main(String[] args) {
		try {
			FileReader f1 = new FileReader("file.txt");
			FileReader f2 = new FileReader("file2.txt");
			MultiFileRead m1 = new MultiFileRead(f1);
			MultiFileRead m2 = new MultiFileRead(f2);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
