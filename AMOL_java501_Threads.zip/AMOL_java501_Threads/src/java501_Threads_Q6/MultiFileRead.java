package java501_Threads_Q6;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class MultiFileRead extends Thread{
	FileReader f;
	public MultiFileRead(FileReader f) {
		// TODO Auto-generated constructor stub
		this.f= f;
		start();
	}
	
	@Override
	public synchronized void run() {
		// TODO Auto-generated method stub
		super.run();
		String temp;
		try {
			BufferedReader br = new BufferedReader(f);
			while((temp=br.readLine())!=null){
				System.out.println(temp);
				sleep(2000);
			}
			br.close();
		} catch (IOException | InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
