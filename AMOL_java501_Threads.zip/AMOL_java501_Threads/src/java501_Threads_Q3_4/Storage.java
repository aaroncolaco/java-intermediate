package java501_Threads_Q3_4;

public class Storage {
	int count;
	private boolean flag= true;
	
	public synchronized int getCount() {
		if(flag == true){
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		flag= true;
		notify();

		System.out.println("Printer Class: " + this.count);
		return count;
	}

	public synchronized void setCount(int count) {
		
		if(flag == false){
		try {
			wait();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	this.count = count;

	System.out.println("Counter Class");
	flag = false;
	notify();
	}
	
	public static void main(String[] args) {
		Storage s = new Storage();
		new Counter(s);
		new Printer(s);
	}
}
