package java501_Threads_Q3_4;

public class Counter extends Thread{
	Storage s;
	public Counter(Storage s) {
		// TODO Auto-generated constructor stub
		this.s = s;
		start();
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		super.run();
		for(int i=0;i<10;i++){
			s.setCount(i);
		}
	}
}
