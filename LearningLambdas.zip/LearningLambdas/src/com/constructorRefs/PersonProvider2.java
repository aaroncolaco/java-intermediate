package com.constructorRefs;

public interface PersonProvider2 {
	public Person getPerson(String name, int age);
}
