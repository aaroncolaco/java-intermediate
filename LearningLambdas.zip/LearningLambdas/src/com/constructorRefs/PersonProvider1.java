package com.constructorRefs;

public interface PersonProvider1 {
	public Person getPerson();
}
