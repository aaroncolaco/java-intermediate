package com.lambdas.learn;

public interface Greetings {
	String greet(String str);
}
