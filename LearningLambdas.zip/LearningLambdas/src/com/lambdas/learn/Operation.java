package com.lambdas.learn;

public interface Operation {
	int operations(int a, int b);
}
